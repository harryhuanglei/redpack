<?php
require_once '../include/common.inc.php';
if($cfg['config']['loginguest']=='0' && !isset($_SESSION['login_uid']) )header('location:../logging.php');
require_once PPCHAT_ROOT.'./include/json.php';
$json=new JSON_obj;
//房间状态
if ($cfg['config']['state'] == '2' and $_SESSION['room_' . $cfg['config']['rid']] != true) {
	header("location:../login.php?rid=".$cfg['config']['rid']);
	exit();
}
if($cfg['config']['state']=='0'){exit("<script>location.href='../error.php?msg=系统处于关闭状态！请稍候……'</script>");exit();}
//游客登录
if(!isset($_SESSION['login_uid']) and $cfg['config']['loginguest']=="1"){gusetLogin();}
//是否登录
if(!isset($_SESSION['login_uid'])){header("location:../logging.php");exit();}

//用户信息
$uid=$_SESSION['login_uid'];
$db->query("update {$tablepre}members set regip='$onlineip' where uid='{$uid}'");
$userinfo=$db->fetch_row($db->query("select m.*,ms.* from {$tablepre}members m,{$tablepre}memberfields ms  where m.uid=ms.uid and m.uid='{$uid}'"));
$_SESSION['login_gid']=$userinfo['gid'];
//游客
if($_SESSION['login_uid']==0){$userinfo['gid'] =17;$userinfo['username']=$userinfo['nickname']=$_SESSION['login_nick'];$userinfo['sex']=$_SESSION['login_sex'];$userinfo['uid']=$_SESSION['login_guest_uid'];}

//黑名单
$query=$db->query("select * from {$tablepre}ban where (username='{$userinfo[username]}' or ip='{$onlineip}') and losttime>".gdate()." limit 1");
while($row=$db->fetch_row($query)){
	exit("<script>location.href='error.php?msg=用户名或IP受限！过期时间".date("Y-m-d H:i:s",$row['losttime'])."'</script>");exit();
}
$query = $db->query("select * from {$tablepre}gag where username='{$userinfo[username]}'  and losttime>" . gdate() . " limit 1");
if($db->fetch_row($query)){$usergag="1";}else{$usergag="0";}
//聊天过滤词汇
//$msg_unallowable=$msg_unallowable.$cfg['config']['msgban'];


//用户组
$query=$db->query("select * from {$tablepre}auth_group order by ov desc");
while($row=$db->fetch_row($query)){
	$groupli.="<div id='group_{$row[id]}'></div>";
	$grouparr.="grouparr['{$row[id]}']=".json_encode($row).";\n";
	$group["m".$row[id]]=$row;
}
//聊天历史记录
$query=$db->query("select * from {$tablepre}chatlog where rid='".$cfg['config']['id']."' and p='false' and state!='1' and `type`='0' order by id desc limit 0,20 ");

while($row=$db->fetch_row($query)){
	$row['msg']=str_replace(array('&amp;', '','&quot;', '&lt;', '&gt;'), array('&', "\'",'"', '<', '>'),$row['msg']);
	if($row[tuid]!="ALL"){
		$omsg="<div style='clear:both;'></div><div class='msg' id='{$row[msgid]}'><div class='msg_head'><img src='../../face/img.php?t=p1&u={$row[uid]}'><span class='u'>{$row[uname]}</span><span class='dui'>对</span><img src='../../face/img.php?t=p1&u={$row[tuid]}'><span class='u'>{$row[tname]}</span><span class='shuo'>说</span></div>
		 <div class='msg_content'>{$row[msg]}</div></div>".$omsg;
	}
	else{
		$omsg="<div class='msg_li'><div style='clear:both;'></div><div class='msg' id='{$row[msgid]}'><div class='msg_head'><img src='../../face/img.php?t=p1&u={$row[uid]}'><span class='u'> {$row[uname]}：</spa></div> <div class='msg_content'>{$row[msg]}</div></div></div>".$omsg;
	}
}
//其他处理
$ts=explode(':',$cfg['config']['tserver']);


if(!isset($_SESSION['room_'.$uid.'_'.$cfg['config'][id]])){
$db->query("insert into  {$tablepre}msgs(rid,ugid,uid,uname,tuid,tname,mtime,ip,msg,`type`)values('{$cfg[config][id]}','{$userinfo[gid]}','{$userinfo[uid]}','{$userinfo[username]}','{$cfg[config][defvideo]}','{$cfg[config][defvideonick]}','".gdate()."','{$onlineip}','登陆直播间','3')");
$_SESSION['room_'.$uid.'_'.$cfg['config'][id]]=1;
}
//QQ客服
$query = $db->query("select m.*,ms.* from {$tablepre}members m,{$tablepre}memberfields ms  where m.uid=ms.uid and m.gid=3 ");
while ($row = $db->fetch_row($query)) {
	$list .= "

  <div class='li'>
    <div class='li_img'><img src='/face/img.php?t=p2&u={$row[uid]}'></div>
    <div class='li_qq'><a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin={$row[realname]}&site=qq&menu=yes' target='oqq'>
    {$row[nickname]}</a></div>
    <div class='li_phone'>{$row[phone]}</div>
  </div>
";
} ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width">
<title>
<?=$cfg['config']['title']?>
</title>
 <meta name="viewport" content="wispanh=device-wispanh, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="default">
<meta name="browsermode" content="application">
<meta name="apple-touch-fullscreen" content="no">
<meta http-equiv="expires" content="0">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" type="image/x-icon" href="<?=$cfg['config']['ico']?>" />
<META HTTP-EQUIV="Pragma" CONTENT="no-cache"> 
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache"> 
<META HTTP-EQUIV="Expires" CONTENT="0">
<link rel="stylesheet" href="./css/index.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="script/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/web_socket.js"></script>
<script type="text/javascript" src="js/json.js"></script>
<script type="text/javascript" src="script/layer.js"></script>
<script src="script/main.m.js"></script>
<script src="../script/device.min.js"></script>
<script>
function eventListener()
{
	document.addEventListener("visibilitychange", function() {
	  if ( !document.hidden ) {
	  	window.location.reload();
	  }
	});
}

$(function () { 
  var isPageHide = false; 
  window.addEventListener('pageshow', function () { 
    if (isPageHide) { 
      window.location.reload(); 
    } 
  }); 
  window.addEventListener('pagehide', function () { 
    isPageHide = true; 
  }); 
})

</script>
<script>
//if (!device.mobile()){window.location = '.';}
var UserList;
var ToUser;
var VideoLoaded=false;
var My={dm:'<?=$_SERVER['HTTP_HOST']?>',rid:'<?=$cfg['config']['rid']?>',roomid:'<?=substr(md5($_SERVER['HTTP_HOST']), 0, 6).$cfg['config']['id']?>',chatid:'<?=$userinfo['uid']?>',name:'<?=$userinfo['username']?>',nick:'<?=$userinfo['nickname']?>',sex:'<?=$userinfo['sex']?>',age:'0',qx:'<?=check_auth('room_admin')?'1':'0'?>',ip:'<?=$onlineip?>',vip:'<?=$userinfo['gid']?>',color:'<?=$userinfo['gid']?>',cam:'0',state:'0',mood:'<?=$userinfo['mood']?>',rst:'<?=$time?>',camState:'1',gag: '<?=$usergag?>'}
var RoomInfo={loginTip:'<?=$cfg['config']['logintip']?>',Msglog:'<?=$cfg['config']['msglog']?>',loginalert: '<?=$cfg['config']['loginalert']?>',logoutalert:'<?=$cfg['config']['logoutalert']?>',msgBlock:'<?=$cfg['config']['msgblock']?>',msgAudit:'<?=$cfg['config']['msgaudit']?>',defaultTitle:document.title,MaxVideo:'10',VServer:'<?=$cfg['config']['vserver']?>',VideoQ:'',TServer:'<?=$ts[0]?>',TSPort:'<?=$ts[1]?>',PVideo:'<?=$cfg['config']['defvideo']?>',AutoPublicVideo:'1',AutoSelfVideo:'0',type:'1',PVideoNick:'',OtherVideoAutoPlayer:'<?=$cfg['config']['livetype']?>',r:'<?=$cfg['config']['rebots_yk']?>',rebots_re: '<?=$cfg['config']['rebots_re']?>'}
var grouparr=new Array();
<?=$grouparr?>
var ReLoad;
var isIE=document.all;
var aSex=['<span class="sex-womon"></span>','<span class="sex-man"></span>',''];
var aColor=['#FFF','#FFF','#FFF'];
var msg_unallowable="<?=$msg_unallowable?>";
   if (typeof console == "undefined") {    this.console = { log: function (msg) {  } };}
    WEB_SOCKET_SWF_LOCATION = "js/WebSocketMain.swf";
    WEB_SOCKET_DEBUG = true;
    var ws, name, client_list={},timeid, reconnect=false;

</script>

<style type="text/css" media="screen">
#flashContent { display: block; text-align: left; }
</style>
</head>

<body style="position: relative; top: 0px; background-image: url(./images/929199.jpg);background-size: cover; overflow: hidden; background-position: initial initial; background-repeat: no-repeat no-repeat;padding: 0;margin: 0;" onload="eventListener();">
<div id="details"></div>
<div id="newsDetail" style="display: none;"></div>
<div class="zhezhao"></div>
<div id="sharedWrap"> </div>
<div id="shared"></div>
<article>
  <div id="logo"> <img src="<?=$cfg['config']['logo']?>" alt="" height="25px"> </div>
  <section id="#head_1">
    <div id="video-flash" class="videoTitle"> <img src="./images/refresh.png" alt="刷新" width="20px" height="20px">
      <div class="video-flashBtn">刷新视频</div>
    </div>
    <!-- 视频 -->
    <div class="video-box">
      <div class="video-wrap">
        <div class="bg-opacity"></div>
      </div>
      <div class="video-wrap" id="view-wrap-container">
        <div id="video-status-container" class="video-status-container"></div>
        <div class="video-win" id="video-win">
        </div>
      </div>
    </div>
    <nav>
      <ul>
        <li class="spec1 active">聊天<span class="activeCart"></span> </li>
        <li class="spec2">客服<span class=""></span> </li>
        <li class="spec3">推广链接<span class=""></span> </li>
        <li>
          <?php
            if($_SESSION['login_uid']>0)
			{
				echo $userinfo['username']." <a href='../minilogin1.php?act=logout'>退出</a>";
			}else {
				echo '<div id="loginBtn" onClick="location.href=\'../minilogin1.php\'">注册/登陆</div>';
			}
			?>
        </li>
      </ul>
    </nav>
  </section>
  <section>
    <div id="publicChat" class="publicChat"><?=$omsg?></div>
    <div id="qqOnline" style="width: 100%; display: none; overflow:auto;" class="white">
		<style type="text/css">
		/* CSS Document */

		body {
			font: normal 11px auto "Trebuchet MS", Verdana, Arial, Helvetica, sans-serif;
			color: #4f6b72;
			background-color: #c2ddf3;
		}

		a {
			color: #FFF;
			text-decoration: none;
		}

		.list {
			float: left;
			margin-bottom: 20px;
		}

		.li {
			float: left;
			margin: 1px;
			width: 110;
			padding: 1px;
			border: 1px solid #aec5d8;
			background-color: #fff;
			height: 208px;
		}

		.li_img img {
			width: 100px;
			height: 140px;
			border: 1px #CCCCCC solid;
			padding: 1px;
			margin: 1px;
		}

		.li_qq {
			background: url(/apps/img/pop_btn1.png) no-repeat;
			display: block;
			margin: 0 auto;
			color: #fff;
			font-size: 14px;
			padding-left: 25px;
			margin-top: 3px;
			width: 80px;
			height: 26px;
			line-height: 26px;
			overflow: hidden
		}

		.li_qq:hover {
			opacity: 0.9;
		}

		.li_phone {
			background: url(/apps/img/pop_btn2.png) no-repeat 1px 3px;
			display: block;
			height: 22px;
			line-height: 22px;
			padding-left: 12px;
			width: 90px;
			margin: 0 auto;
			font-size: 13px;
			overflow: hidden;
			color: #F00
		}
          .msg_content img{max-height:50px; cursor:pointer;}
	</style>
</head>

<body style="overflow:auto">
<div class='list'>
	<?= $list ?>
</div>
    </div>
    <div class="kuaiXun" style="width: 100%; display: none;">
      <iframe src="/apps/tg.php?rid=<?= $cfg['config']['rid'] ?>" frameborder="0" scrolling-y="auto" width="99.9999%"  height=100%></iframe>
    </div>
  </section>
</article>
<div id="footer" style="display: block;">
  <div class="sendBtn fr" id="sendBtn">发送</div>
  <div id="sharedBtn"> <span>分享</span> </div>
  <div class="smile"> <img src="./images/smile.png" alt="表情" width="26px" height="26px"> </div>
  <div id="editor">
    <div class="messageEditor" id="messageEditor" contenteditable="true"></div>
  </div>
</div>
<div class="loginWrap"></div>
<div class="tipMesWrap"></div>
<div class="setting-expression-layer" style='display: none;'>
  <div class="expression" id="expressions">
    <table class="expr-tab expr-tab1">
    </table>
  </div>
</div>
<script>OnInit();
$(function () {
            $("#publicChat img").attr('onclick', '');
            $("#publicChat").on('click', '.msg_content img', function () {
                open_img($(this).attr('src'));
            });
        });
  </script>
</body>
</html>
